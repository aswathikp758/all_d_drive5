import React from "react";

class Home extends React.Component {
  render() {
    return <h2>This is Homepage..</h2>;
  }
}
export default Home;