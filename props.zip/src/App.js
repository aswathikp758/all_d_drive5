
import React, {Component } from 'react';
import './App.css';
import Todo from './component/Todo';
class App extends Component{
  state={
    myString:"Hello",
    
  };


 handleChange=()=>{
  this.setState({
    myString:"haii"
  });
 }

  render(){
    return(
      <div className='App'>
      
       <Todo myStringOne={this.state.myString}/>
       {/* myStringOne is a props.using for data passing to the component */}
      
      


      {/* text change using button click */}
      <button onClick={this.handleChange}>Change Text</button>
      </div>



   );
  }
}

export default App;