
import './App.css';
import Users from './components/Users';

function App() {
  return (
    <div className="App">
      <Users/>
    </div>
  );
}

export default App;
