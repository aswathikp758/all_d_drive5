import React, { Component } from 'react'

export default class Card extends Component {
   componentWillUnmount(){
    console.log("Unmounted");
   }


    render() {
    return (
      <div>Card</div>
    )
  }
}
