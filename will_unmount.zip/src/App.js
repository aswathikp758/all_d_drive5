import React, { Component } from 'react'
import Card from './components/Card';
export default class App extends Component {
 
 constructor(){
    super()
    this.state={
        show:true,
    };
 }
 deleting=()=>{
    this.setState({show:false})
 }

    render() {
    return (
      <div>
        {this.state.show?<Card/>:""}
        <button onClick={this.deleting}>Add</button>
      </div>
    )
  }
}
