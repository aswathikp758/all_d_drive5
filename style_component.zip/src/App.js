import { BlueButton, GreenButton,Button, Button2 } from './components/Button.styles';
import './App.css';




function App() {
  return (
    <div className="App">

      {/* ----first example---- */}
  <Button>Click this Button</Button>  
  <BlueButton>Click this Button</BlueButton>  
  <GreenButton>Click this Button</GreenButton>


  {/* ------second example----------- */}

  <Button2 backgroundColor="violet">Click this Button</Button2>  


 
    </div>
   
  );
}

export default App;
