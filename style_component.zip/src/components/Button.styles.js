import styled from "styled-components";
//  ------first example-----------
export const Button =styled.button`
width: 200px;
height:50px;
background-color: red;
`;
export const GreenButton =styled.button`
width: 200px;
height:50px;
background-color: green;
`;
export const BlueButton =styled.button`
width: 200px;
height:50px;
background-color: blue;
`;

//---------second example---------
export const Button2 =styled.button`
width: 200px;
height:50px;
background-color: ${(props)=>props.backgroundColor};
`;











// export const StyledButton = styled.button`
// border: 2px solid #4caf50;
// background-color: ${(props)=> (props.variant==='outline'?'#FFF':'#4caf50')};
// color: ${(props)=>(props.variant==='outline'?'#4caf50':'#FFF')};
// padding: 15px 32px;
// text-align: center;
// text-decoration: none;
// display: inline-block;
// font-size: 16px;
// cursor: pointer;
// transition: 0.5s all ease-out;
// `;
// export const RedButton=styled.button`
// width:200px;
// height:50px;
// background-color:red;`;