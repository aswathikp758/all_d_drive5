import React from 'react';
import Higherordercom from './Hoc.js';

const Student1=(props)=>{
    return(
        <div>
            Student1
            <h3>{props.num}</h3>
            <button onClick={props.handleEvent}>Count Inc</button>
        </div>
    )

}
export default Higherordercom(Student1)