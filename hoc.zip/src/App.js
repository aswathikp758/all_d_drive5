import './App.css';
import Student1 from './Student1';
import Student2 from './Student2';

function App() {
  return (
    <div className="App">
    <Student1/>
    <Student2/> 
    </div>
  );
}

export default App;
