import React, { Component } from 'react'

export default class App extends Component {

  constructor(){
    super();
    this.state={
      num:0,
    };
    console.log("consturctor");
    

  }
  componentDidMount(){
    console.log("Mounting");
  }
  counting=()=>{
    this.setState({num:1})
  }


  render() {
    return (
      <div>
        {console.log("Rendering")}
        <h1>Hai</h1>
        <h1>{this.state.num}</h1>
        <button onClick={this.counting}>count</button>
      </div>
    )
  }
}
