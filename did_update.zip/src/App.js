import React, { Component } from 'react'

export default class App extends Component {
 
  constructor(){
    super();
    console.log("constuctor")
    this.state={
      count:0,
    };
  }
  componentDidMount(){
    console.log("mounting")
  }
  componentDidUpdate(){
    console.log("updating");
  }
  counting=()=>{

    this.setState((pre)=>{
      return{
        count:pre.count+1,
      };
    });

  };

  render() {
    return (
      <div>
        <h1>{this.state.count}</h1>
        {console.log("rendering")}
        <button onClick={this.counting}>Add</button>
      </div>
    )
  }
}
