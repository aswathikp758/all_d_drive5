import React from "react";
function Event(){

    return(
        // Using Functional Component
        <div>
          {/* Example1 */}
          <button onClick={ alert(1) }>Click</button> 
          {/* This is not correct.In this code alert generate before button click */}


          <button onClick={ ()=>{ alert('welcome')}}>Click</button>
          {/* In OnClick event can't call function directly. only put function body into it. */}


          {/* another way -----------------create new function.can't using test() function call.*/}
          <button onClick={test}>Click</button>



          {/* Example2 -- using variables */}
          <button onClick={ test1 }>Click</button>

        </div>

       
    )
}
// function test()
// {
//     alert('test function');
// }


var x=10;
function test1()
{
    x++;
    alert(x);
}
export default Event;