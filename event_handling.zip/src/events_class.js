import React, { Component } from "react";

class Events_class extends Component{
    //normal function

    //  clickhandler(){
    //     alert('welcome');
    // }

    //Arrow function
    // clickhandler=()=>{
    //         alert('welcome');
    //     }


    // This is not a correct way .using class component like this the function binding manually.So use the arrow functions.and easy to handle.
//----------------using counter-----------

constructor(props)
{
    super(props);
    this.state={
        counter:0
    }
}
increment=()=>{
    this.setState((prev,props)=>(
        { counter:prev.counter+1}
    ));
}
decrement=()=>{
    this.setState((prev,props)=>(
        { counter:prev.counter-1}
    ));
}
    render(){
        return(
             <div>
            {/* <button onClick={ this.clickhandler}>Click</button> */}
        <button onClick={ this.increment}>+</button>
        <button onClick={ this.decrement}>-</button>
        <p>You have clicked {this.state.counter}times</p>
        </div>
        );
       
        }
    
}
export default Events_class;