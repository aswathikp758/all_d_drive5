import React, { Component } from 'react'
import "./TodoApp.css";
export default class TodoApp extends Component {
  constructor(props){
    super(props);
    this.state={
      items:[],
      txtContent:""
    };
  }
  txtChange=(e)=>{
    this.setState({txtContent:e.target.value})
  }
  addItem=(e)=>{
    let currentText=this.state.txtContent;
    let currentItems=this.state.items;
    currentItems.push(currentText);
    this.setState({items:currentItems});
  }
  removeItem=(i)=>{
    // if(!window.confirm("Are you sure you want to delete this.?")){
    //   return;
    // }
    let currentItems=this.state.items;
    currentItems.splice(i,1);                         
    // The splice() method adds and/or removes array elements. The splice() method overwrites the original array.
    this.setState({items:currentItems});
  }
  render() {
    
    return (
      <div className="todo-container ">
       
      
        <h1>TodoApp</h1>
            <input type="text" className='input-section' onChange={this.txtChange} placeholder='Enter Items...'/><br></br>
            <button className="add" onClick={this.addItem}>ADD</button>
       
        <ul>
          {this.state.items.map((itm,k)=>{
            return(
              <li>{itm}<button className="icon" onClick={()=>{this.removeItem(k)}}><i className="fa-solid fa-trash-can "></i></button></li>
            )
          })}
        </ul>
        
       
        </div>
    )
  }
}
