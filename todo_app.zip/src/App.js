import React, { Component } from 'react'
import TodoApp from './component/TodoApp/TodoApp'

export default class App extends Component {
  render() {
    return (
      <div><TodoApp/></div>
    )
  }
}
