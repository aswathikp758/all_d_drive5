import './App.css';
// import Controlled from './components/Controlled';
import Un_component from './components/Un_component';


function App() {
  return (
    <div className="App">
    <Un_component/>
    {/* <Controlled/> */}
    </div>
  );
}

export default App;
